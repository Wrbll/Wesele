document.addEventListener('DOMContentLoaded', () => {
    // Logika przełączania podstron
    const navLinks = document.querySelectorAll('.main-nav a.nav-link');
    const contentSections = document.querySelectorAll('.content-section');

    navLinks.forEach(link => {
        link.addEventListener('click', (e) => {
            e.preventDefault(); // Zapobiega domyślnemu zachowaniu linku (przewijaniu do góry)
            const targetSectionId = link.dataset.section;

            // Ukryj wszystkie sekcje i usuń klasę 'active' z linków
            contentSections.forEach(section => {
                section.classList.remove('active');
            });
            navLinks.forEach(navLink => {
                navLink.classList.remove('active');
            });

            // Pokaż wybraną sekcję i dodaj klasę 'active' do klikniętego linku
            const targetSection = document.getElementById(targetSectionId);
            if (targetSection) {
                targetSection.classList.add('active');
            }
            link.classList.add('active');
        });
    });

    // Ustawienie początkowej sekcji aktywnej (jeśli nie jest ustawiona w HTML)
    const activeSectionInHtml = document.querySelector('.content-section.active');
    if (!activeSectionInHtml && contentSections.length > 0) {
        contentSections[0].classList.add('active');
        navLinks[0].classList.add('active');
    }

    // Logika licznika czasu do ślubu
    const countdownElement = document.getElementById("countdown");
    const weddingDate = new Date("2025-09-20T15:00:00"); // Data i godzina ślubu

    function updateCountdown() {
        const now = new Date();
        const diff = weddingDate - now;

        if (diff <= 0) {
            countdownElement.innerText = "To już dziś! 💍";
            return;
        }

        const days = Math.floor(diff / (1000 * 60 * 60 * 24));
        const hours = Math.floor((diff / (1000 * 60 * 60)) % 24);
        const minutes = Math.floor((diff / (1000 * 60)) % 60);
        const seconds = Math.floor((diff / 1000) % 60);

        countdownElement.innerText =
            `Zostało: ${days} dni, ${hours} godz., ${minutes} min, ${seconds} sek`;
    }

    // Uruchom licznik od razu i aktualizuj co sekundę
    updateCountdown();
    setInterval(updateCountdown, 1000);

    // Logika dla Easter Egg
    const easterEggElement = document.getElementById('easter-egg');

    if (easterEggElement) {
        easterEggElement.addEventListener('click', () => {
            const videoUrl = easterEggElement.dataset.videoUrl;
            if (videoUrl) {
                // Opcjonalnie: alert przed przekierowaniem (możesz usunąć)
                alert('Pa tera');
                window.open(videoUrl, '_blank'); // Otworzy filmik w nowej karcie
            }
        });

        // Opcjonalnie: możesz dodać też logikę na podwójne kliknięcie (dblclick)
        // lub dłuższe najechanie (mouseenter/mouseleave z timerem) dla większej trudności.
    }
});